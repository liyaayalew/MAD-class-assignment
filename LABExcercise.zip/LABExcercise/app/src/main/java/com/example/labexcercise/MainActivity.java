package com.example.labexcercise;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        TextView textView = new TextView(this);
        textView.setText(getString(R.string.app_title));
        layout.addView(textView);

        Button button = new Button(this);
        button.setText(getString(R.string.button_click_me));
        layout.addView(button);

        final RadioGroup radioGroup = new RadioGroup(this);
        RadioButton radioButton1 = new RadioButton(this);
        radioButton1.setText(getString(R.string.radio_button_1));
        radioButton1.setId(View.generateViewId());

        RadioButton radioButton2 = new RadioButton(this);
        radioButton2.setText(getString(R.string.radio_button_2));
        radioButton2.setId(View.generateViewId());

        radioGroup.addView(radioButton1);
        radioGroup.addView(radioButton2);
        layout.addView(radioGroup);

        final EditText editText = new EditText(this);
        editText.setHint(getString(R.string.edittext_hint));
        layout.addView(editText);

        setContentView(layout);

        button.setOnClickListener(v -> {
            String enteredText = editText.getText().toString();
            int selectedId = radioGroup.getCheckedRadioButtonId();

            if (selectedId != -1) {
                RadioButton selectedRadioButton = findViewById(selectedId);
                String message = getString(R.string.toast_radio_chosen, enteredText, selectedRadioButton.getText());
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, getString(R.string.toast_no_radio), Toast.LENGTH_SHORT).show();
            }
        });
    }
}